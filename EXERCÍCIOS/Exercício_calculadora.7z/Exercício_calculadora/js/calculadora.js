const numero1 = Number(document.getElementById('num1').value);
const numero2 = Number(document.getElementById('num2'));
const resultado = document.getElementById('result');
const r_maior_menor_igual = document.getElementById('maior_menor_igual')
const r_pares = document.getElementById('pares')
const r_multiplos = document.getElementById('multiplus')
const r_soma_par_impar = document.getElementById('soma_par_impar')
const negativo = document.getElementById('1ºnegativo')

// Para calcular
function somar (){
    resultado.textContent = numero1 + numero2
}
function subtrair (){
    resultado.textContent = Number(numero1.value) - Number(numero2.value)
}
function multiplicar (){
    resultado.textContent = Number(numero1.value) * Number(numero2.value)
}
function dividir (){
    resultado.textContent = Number(numero1.value) / Number(numero2.value)
}
function reset (){
    numero1.Value = "";
    numero2.Value = "";
    resultado.innerHTML = "";
}

// Para verificações
function maior_menor_igual(){
    if (numero1 > numero2) {
        r_maior_menor_igual.textContent = "O número 1 é maior que o número 2"
    } else if (numero2 > numero1) {
        r_maior_menor_igual.textContent = "O número 2 é maior que o número 1"
    } else {
        r_maior_menor_igual.textContent = "Os dois são iguais"
    }
}
function pares(){
    if (numero1 % 2 == 0 & numero2 % 2 == 0 ){
        r_pares.textContent = "Os dois são pares"
    } else if (numero1 % 2 == 1 & numero2 % 2 == 0 ){
        r_pares.textContent = "Apenas o 2º número é par"
    } else if (numero1 % 2 == 0 & numero2 % 2 == 1 ){
        r_pares.textContent = "Apenas o 1º número é par"
    } else {
        r_pares.textContent = "Nenhum é par"
    }
}
function multiplos(){
    if (numero1 % numero2 == 0) {
        r_multiplos = "O 1º número é múltiplo do 2º número"
    } else if(numero2 % numero1 == 0) {
        r_multiplos = "O 2º número é múltiplo do 1º número"
    } else {
        r_multiplos = "Não são multiplus"
    }
}
function soma_par_impar() {
    if ((numero1+numero2) % 2 == 0) {
        r_soma_par_impar = "a soma dos dois é par"
    } else {
        r_soma_par_impar = "a soma dos dois é ímpar"  
    }
}
function soma_maior(){
    if ((numero1+numero2) > 10) {
        r_soma_par_impar = "A soma dos dois número é maior que 10"
    } else {
        r_soma_par_impar = "A soma dos dois número é menor que 10"
    }
}
function primeiro_negativo(){
    if ( numero1 < 0) {
        negativo = "✔"
    } else {
        negativo = "❌"
    }
}